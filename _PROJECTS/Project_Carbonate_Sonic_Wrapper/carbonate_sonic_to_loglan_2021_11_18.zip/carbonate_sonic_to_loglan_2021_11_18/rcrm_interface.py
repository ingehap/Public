import sys
import os
import configparser
import numpy as np
import pandas as pd
from external.rokdoc_carbonate_regression_models.calculate_prt import estimate_prt
from external.rokdoc_carbonate_regression_models.run_regression import run_regression

def predict_prt(inp_df):
    """Uses RokDoc carbonate regression to estimate petrophysical rock types

    Parameters
    ----------
    inp_df : pandas.DataFrame
        A Pandas Dataframe that contains input logs as column vectors

    Returns
    -------
    predict_prt : numpy.ndarray
        An one-dimensional NumPy array containing the petrophysical rock type values
    """
    return estimate_prt(inp_df).to_numpy()

def predict_sonic(inp_df, method):
    """Uses RokDoc carbonate regression to estimate sonic velocities vp and vs

    Parameters
    ----------
    inp_df : pandas.DataFrame
        A Pandas Dataframe that contains input logs as column vectors
    method : str
        A string that indicates what method is used. Possible values are 'ls' and 'mm'.

    Returns
    -------
    predict_sonic : tpl
        A 2-tuple where the first component is predicted VP as a NumPy array and the second 
        component is predicted VS as a NumPy array
    """
    print("Current working directory = ", os.getcwd())
    config = configparser.ConfigParser()
    config.read('./loglan/external/rokdoc_carbonate_regression_models/rcrm_interface.ini')
    cwd = os.getcwd()
    if method == 'ls':
        result = run_regression(inp_df, cwd + config['LithoScanner']['VP_LOC'], cwd + config['LithoScanner']['VS_LOC'])
    elif method == 'mm':
        result = run_regression(inp_df, cwd + config['MultiMin']['VP_LOC'], cwd + config['MultiMin']['VS_LOC'])
    else:
        sys.exit("Illegal method was used")
    return result.iloc[:,0].to_numpy(), result.iloc[:,1].to_numpy()

# Testing code

def write_rms(txt, vec):
    result = np.sqrt(np.nanmean(np.square(vec)))
    print(txt, result)

