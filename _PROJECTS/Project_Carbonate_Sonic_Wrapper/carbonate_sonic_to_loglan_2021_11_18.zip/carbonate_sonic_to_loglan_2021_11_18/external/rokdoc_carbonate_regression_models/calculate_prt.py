import numpy as np
import pandas as pd

# Constants for cut-offs
"""
From Geolog script:
Interval	ln Out	CMFFCUTOFF	REAL		    0.04	CMR free fluid		
Interval	In Out	CBP8 CUTOFF	REAL		    0.025	Bin porosity 8 - CMR			
Interval	ln Out	DWSI CUTOFF	REAL	W/W	0.15	Weight percent silicon			
Interval	In Out	BFV CUTOFF	REAL	VA/	0.047	Bound fluid volume - CMR			
Interval	ln Out	PHIT CUTOFF	REAL	VA/	0.05	Total Porosity			
Interval	In Out	VSH_DS_CUTOFF	REAL	VA/	0.5	Volume of Shale			
Interval	ln Out	VSH_DN_CUTOFF	REAL	VA/	0.15	Volume of Shale			
Interval	In Out	VSH NMR CUTOFF	REAL	V/V	0.35	Volume of Shale			
"""
cmff_cutoff = 0.04
cbp8_cutoff = 0.025
dwsi_cutoff = 0.15
bfv_cutoff = 0.047
tcmr_cutoff = 0.05
vsh_ds_cutoff = 0.5
vsh_dn_cutoff = 0.15
vsh_mr_cutoff = 0.35


def _estimate_prt(cmff, cbp8, dwsi, bfv, tcmr, vsh):
    # In most cases there will not be both VSH_DN and VSH_DS available. It has mainly
    # been used to distinguish between PRTs 3 and 9, so they will be merged in this version
    vsh_ds = vsh_dn = vsh

    # PRTCOLOR = ‘GREEN’
    # PRT_DESC = 'Tight / non-net'
    idx1 = np.all(np.stack((cmff < cmff_cutoff, vsh_ds < vsh_ds_cutoff, tcmr < tcmr_cutoff), axis=1), axis=1)
    # PRT_COLOR = 'BLUE'
    # PRT_DESC = 'Fibrous fans without stevensite / boundstone, grainstone (SFF/silicified)'
    idx2 = np.all(np.stack((cmff > cmff_cutoff, dwsi < dwsi_cutoff, cbp8 > cbp8_cutoff, bfv < bfv_cutoff), axis=1),
                  axis=1)
    # PRT_COLOR ='RED'
    # PRT DESC = 'Fibrous fans without stevensite / grainstone'
    idx3 = np.all(
        np.stack((cmff > cmff_cutoff, dwsi < dwsi_cutoff, cbp8 < cbp8_cutoff, bfv < bfv_cutoff, vsh_dn < vsh_dn_cutoff),
                 axis=1), axis=1)
    # PRT 4 not silicified?
    # PRTCOLOR = 'ORANGE'
    # PRT_DESC = 'PRT 2 with high SW (presence of ANDevensite)'
    idx4 = np.all(np.stack((cmff > cmff_cutoff, dwsi < dwsi_cutoff, bfv > bfv_cutoff), axis=1), axis=1)
    # PRT_COLOR = 'YELLOW'
    # PRT_DESC = 'Silicified (SFF/silic if ied)'
    idx5 = np.all(np.stack((cmff > cmff_cutoff, dwsi > dwsi_cutoff), axis=1), axis=1)
    # PRTCOLOR = 'DARK_GREEN'
    # PRT_DESC = 'Argillaceous / non-net'
    idx6 = np.all(np.stack((cmff < cmff_cutoff, vsh_ds > vsh_ds_cutoff, tcmr > tcmr_cutoff), axis=1), axis=1)
    # PRT_COLOR ='PURPLE'
    # PRT_DESC = 'Fibrous fans without stevensite / grainstone'
    # idx9 = np.all(np.stack((cmff < CMFF_CUTOFF, vsh_ds < VSH_DS_CUTOFF, tcmr < TCMR_CUTOFF), axis=1), axis=1)

    prt = np.nan * np.ones(cmff.shape)
    found = np.zeros(cmff.shape, dtype='bool')

    prt[idx1] = 1
    found[idx1] = True

    prt[np.logical_and(idx2, ~found)] = 2
    found = np.logical_or(found, idx2)

    prt[np.logical_and(idx3, ~found)] = 3
    found = np.logical_or(found, idx3)

    # prt[np.logical_and(idx9, ~found)] = 9
    # found = np.logical_or(found, idx9)

    prt[np.logical_and(idx4, ~found)] = 4
    found = np.logical_or(found, idx4)

    prt[np.logical_and(idx5, ~found)] = 5
    found = np.logical_or(found, idx5)

    prt[np.logical_and(idx6, ~found)] = 6
    found = np.logical_or(found, idx6)

    prt[~found] = 1

    return prt


def estimate_prt(inp_df):
    """
    Estimate Petrophysical Rock Types (PRT) by the algorithm developed at the Bacalhau asset in 2020.

    Parameters
    ----------
    inp_df: pd.DataFrame
        input dataframe, will be tested for the correct logs

    Returns
    -------
    prt : pd.DataFrame
        calculated PRT
    """

    if not isinstance(inp_df, pd.DataFrame):
        raise ValueError(f'estimate_prt: input is not a DataFrame')
    else:
        inp_df.columns = inp_df.columns.str.upper()
    if not np.all([
        'CMFF' in inp_df.columns,
        'CBP8' in inp_df.columns,
        'DWSI' in inp_df.columns,
        'BFV' in inp_df.columns,
        'TCMR' in inp_df.columns,
        'VSH' in inp_df.columns
    ]):
        raise ValueError('estimate_PRT: incorrect inputs or inputs missing: {}'.format(inp_df.columns))

    prt = _estimate_prt(np.array(inp_df['CMFF']), np.array(inp_df['CBP8']), np.array(inp_df['DWSI']),
                        np.array(inp_df['BFV']), np.array(inp_df['TCMR']), np.array(inp_df['VSH']))

    prt_df = pd.DataFrame(columns=['PRT'], index=inp_df.index, data=prt)

    return prt_df
