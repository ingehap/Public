import inspect
import sys
import warnings

import rokdoc as rd

from equinor_rock_physics_module import carbonate_regression_models
from equinor_rokdoc_utilities import rd_utilities


def calculate_prt(multi_log_col, wis=None, return_info_array_only=False):
    multi_log_col, wis = rd_utilities.ikon_to_equinor_objects(multi_log_col, wis)
    try:
        prt_info = rd_utilities.InfoArray('prt', var_type='Facies', unit='unitless')

        info_array = [prt_info]
        input_data = [multi_log_col]

        args = ()
        filter_args = {}

        plugin_fcn = carbonate_regression_models.estimate_prt

        if return_info_array_only:
            return info_array
        else:
            return rd_utilities.run_plugin(plugin_fcn, info_array, input_data, wis, *args, filter_args=filter_args)
    except ValueError:
        rd.ikon_display_warning(str(sys.exc_info()))
        warnings.warn('{} failed: {}'.format(inspect.stack()[0][3], str(sys.exc_info())), RuntimeWarning)
        return
