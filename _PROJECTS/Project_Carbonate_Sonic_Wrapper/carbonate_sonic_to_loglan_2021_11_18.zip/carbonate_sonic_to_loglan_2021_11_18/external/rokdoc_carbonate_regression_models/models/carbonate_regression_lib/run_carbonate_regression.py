import inspect
import os
import sys
import warnings

import rokdoc as rd

from equinor_rock_physics_module import carbonate_regression_models
from equinor_rokdoc_utilities import rd_utilities


def calculate_carbonate_regression(log_col, vp_input_file, vs_input_file, path_name=None, wis=None,
                                   return_info_array_only=False):
    log_col, wis = rd_utilities.ikon_to_equinor_objects(log_col, wis)

    try:
        vp_info = rd_utilities.InfoArray('vp_reg', var_type='Vp', unit='m/s')
        vs_info = rd_utilities.InfoArray('vs_reg', var_type='Vs', unit='m/s')

        info_array = [vp_info, vs_info]
        input_data = [log_col]

        args = (vp_input_file, vs_input_file,)
        filter_args = {}
        plugin_kwargs = {'model_dir': path_name}
        plugin_fcn = carbonate_regression_models.run_regression

        if return_info_array_only:
            return info_array
        else:
            return rd_utilities.run_plugin(plugin_fcn, info_array, input_data, wis, *args, filter_args=filter_args,
                                           plugin_kwargs=plugin_kwargs)

    except ValueError:
        rd.ikon_display_warning(str(sys.exc_info()))
        warnings.warn('{} failed: {}'.format(inspect.stack()[0][3], str(sys.exc_info())), RuntimeWarning)
        return


def calculate_carbonate_regression_mm(log_col, wis=None, return_info_array_only=False):
    # Hard-coded names for model files to avoid users having to search for them
    path_name = [s for s in sys.path if 'carbonate_regression_plugins' in s][0]
    vp_input_file = path_name + os.path.sep + 'mm_VP_DT_2009_3_EQNR_3_clean_nn.pkl'
    vs_input_file = path_name + os.path.sep + 'mm_VS_DTS_2009_3_EQNR_3_clean_nn.pkl'
    return calculate_carbonate_regression(log_col, vp_input_file, vs_input_file, path_name=path_name, wis=wis,
                                          return_info_array_only=return_info_array_only)


def calculate_carbonate_regression_ls(log_col, wis=None, return_info_array_only=False):
    # Hard-coded names for model files to avoid users having to search for them
    path_name = [s for s in sys.path if 'carbonate_regression_plugins' in s][0]
    vp_input_file = path_name + os.path.sep + 'dw_VP_DT_2009_3_EQNR_3_clean_nn.pkl'
    vs_input_file = path_name + os.path.sep + 'dw_VS_DTS_2009_3_EQNR_3_clean_nn.pkl'
    return calculate_carbonate_regression(log_col, vp_input_file, vs_input_file, path_name=path_name, wis=wis,
                                          return_info_array_only=return_info_array_only)
