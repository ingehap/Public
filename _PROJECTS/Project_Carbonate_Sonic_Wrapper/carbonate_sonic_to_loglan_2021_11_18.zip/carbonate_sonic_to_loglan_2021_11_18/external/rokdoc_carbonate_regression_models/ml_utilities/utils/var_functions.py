import numpy as np
from sklearn import preprocessing
import pandas as pd


def generate_dummy_vars(inp_frame, class_var, ohe=None):
    """
    From categorical variables generate a one-hot-encoder, i.e. each value in the categorical variable becomes a binary
    variable. See sklearn.preprocessing.OneHotEncoder

    Parameters
    ----------
    inp_frame : pd.DataFrame
        input data containing categorical variables
    class_var : str
        name of categorical variable
    ohe : preprocessing.OneHotEncoder
        one-hot-encoder object

    Returns
    -------
    dum_features, no_dummy_cols, dum_var_names : (np.ndarray, int, np.ndarray)
        dum_features: 2D array with transformed dummy variables, no_dummy_cols: number of columns in returned array,
        dum_var_names: automatically generated feature names
    """
    from pandas.api.types import is_numeric_dtype

    if is_numeric_dtype(inp_frame[class_var]):
        # Make sure that the chosen indicator variable contains discrete values
        inp_frame = inp_frame.astype({class_var: 'int32'})

    features_in = np.array(inp_frame[class_var]).reshape(-1, 1)

    if ohe is None:
        classes = features_in
        ohe = preprocessing.OneHotEncoder(categories='auto', sparse=False)
        ohe.fit(classes)

    dum_features = ohe.transform(features_in)
    no_dummy_cols = dum_features.shape[1]
    dum_var_names = ohe.get_feature_names()

    return dum_features, no_dummy_cols, dum_var_names


def import_model(model_file_name):
    """
    Utility to import a pickled dict containing information needed to run a classification or regression based on
    a calibrated model.

    Parameters
    ----------
    model_file_name : str
        full name including path for model file

    Returns
    -------
    models, scaler, ohe, label_var, label_units, feature_var, cat_var : Any
        models: various regression or classification models from sklearn or tensorflow keras, scaler: proprocessing
        Robust Scaler, label_var: name(s) of label variable(s), label_unit: unit(s) of label variable(s), cat_var:
        categorical variables that should be encoded with one-hot-encoder
    """

    from tensorflow.keras.models import load_model
    from pickle import load

    with open(model_file_name, 'rb') as fin:
        # 11.04.2021 HFLE: There is an issue that is not connected to the local function, in that a warning is issued
        # when the model is loaded, claiming that it is of an older version. This is debugged in detail, and the model
        # IS of the correct version, so the error arise elsewhere. To avoid confusion, the warning is suppressed here
        import warnings
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", category=UserWarning)
            mod_dict = load(fin)

    if mod_dict['model_type'] == 'Keras_nn':
        models = load_model(mod_dict['nn_mod'])
    elif mod_dict['model_type'] in ['GridSearchCV', 'ExtraTrees']:
        models = mod_dict['model']
    else:
        raise ValueError('unknown model type {}'.format(mod_dict['model_type']))

    scaler = mod_dict['scaler']
    label_var = mod_dict['label_var']
    label_units = mod_dict['label_units']
    feature_var = mod_dict['feature_var']

    ohe = None
    cat_var = []
    if mod_dict['ohe']:
        with open(mod_dict['ohe'], 'rb') as f:
            try:
                ohe_dict = load(f)
                ohe = ohe_dict['ohe']
                cat_var = ohe_dict['cat_var']
            except FileExistsError:
                pass

    return models, scaler, ohe, label_var, label_units, feature_var, cat_var
