collate module
==============

.. automodule:: collate
   :members:
   :undoc-members:
   :show-inheritance:
