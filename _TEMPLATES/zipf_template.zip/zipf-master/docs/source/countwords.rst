countwords module
=================

.. automodule:: countwords
   :members:
   :undoc-members:
   :show-inheritance:
