plotcounts module
=================

.. automodule:: plotcounts
   :members:
   :undoc-members:
   :show-inheritance:
