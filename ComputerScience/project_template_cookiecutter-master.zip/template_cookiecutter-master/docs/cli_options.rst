.. _command_line_options:

Command Line Options
--------------------

.. click:: cookiecutter.__main__:main
  :prog: cookiecutter
