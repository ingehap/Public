'''
List of functions:
- gardner - convert vp to vs with Castagna eq.
- bellotti_consolidated
- bellotti_unconsolidated
- lindseth
'''

import numpy as np
import pylab
import statsmodels.api as sm

def rhob_gardner(vp,a=0.23,b=0.25):
    '''
    (vp,a=0.23,b=0.25)
    *Input parameters:
     - vp - ft/s (use a=0.31, b=0.25 for metric)
    *Returns:
     - den - g/cc
    '''
    return a * vp**b

def rhob_bellotti_consolidated(dt):
    '''
    *Input parameters:
     - dt - travel time - us/ft
    *Returns:
     - den - g/cc
     '''
    return (3.28 - dt / 89)

def rhob_bellotti_unconsolidated(dt):
    '''
    *Input parameters:
     - dt - travel time - us/ft
    *Returns:
     - den - g/cc
     '''
    return (2.75 - 2.11 * (dt - 47)/(dt+200))

def rhob_lindseth(vp):
    '''
    *Input parameters:
     - vp - ft/s
    *Returns:
     - den - g/cc
     '''
    return (vp - 3460)/(0.308 * vp)

def qq_plot(x_list):
    x = np.array(x_list, dtype=np.float64)
    ave = np.mean(x)
    s_sdev = np.std(x, ddof=1)
    print('Average is ', ave)
    print('Sample standard deviation is ', s_sdev)
    norm_residual = (x - ave) / s_sdev
    sm.qqplot(norm_residual, line='45')
    pylab.show()

# Berg et al.
# "Drilling, Completion, and Openhole Formation Evaluation of High-Angle Wells in 
# High-Density Cesium Formate Brine: The Kvitebjørn Experience, 2004 - 2006"
# SPE/IADC 105733
#
# Pedersen et al.
# "Understanding the Effects of Cesium/Potassium Formate Fluid on Well Log Response - 
# A Case Study of the Kristion and Kvitebjorn Fields, Offshore Norway"
# SPE 103067

def rhob_corr_cs(rhob, pef, pe_lith):
    return rhob * (1.0 - 0.1714 * (pef - pe_lith) * 0.01)

def sxo_cs(rhomanc, rhog, rho_mf, c, rhib_corr_cs, pef, pe_lith):
    return (rhomanc - rhog)/(rho_mf - rhog + c * (rhomanc - rhob_corr_cs)/(pef - pe_lith))

def phid_cs(rhomanc, rhob_corr_cs, sxo_cs, rho_mf, rhog):
    return (rhomanc - rhob_corr_cs)/(rhomanc - (sxo_cs * rho_mf + (1.0 - sxo_cs) * rhog))

# Sonic porosities

def phis_wyllie(dt_ma, dt_mf, cp, gc, dt):
    vp = 304800 / dt
    vp_mf = 304800 / dt_mf
    vp_ma = 304800 / dt_ma
    phis_wyllie = gc * (1.0/cp) * (dt_ma - dt) / (dt_ma -dt_mf)
    return np.clip(phis_wyllie, 0.001, 0.5)
     
def raymer_hunt_gardner(dt_ma, dt_mf, cp, gc, dt):
    vp = 304800 / dt
    vp_mf = 304800 / dt_mf
    vp_ma = 304800 / dt_ma
    aa = (1.0 - 0.5 * vp_mf /vp_ma)
    bb = 1.0 - vp / vp_ma
    phis_rhg = gc * (aa - np.sqrt(aa**2 - bb))
    return np.clip(phis_rhg, 0.001, 0.5)