#!/usr/bin/env python3

import os
import sys
import geolog
import pygg

def delete_log(welname, setout, logout):
    projname = os.environ.get("PG_PROJECT")
    if not pygg.init(projname):
        print(f"Could not initialize project {projname} \n ...")
        sys.exit()
    if not pygg.open(pygg.WELL, pygg.STATUS_NEW, welname):
        print(f"Could not open well {welname} \n ...")
        sys.exit()
    if not pygg.open(pygg.SET, pygg.STATUS_OLD, setout):
        print(f"Could not open set {setout} \n ...")
        sys.exit()
    pygg.delete(pygg.LOG, logout)
    pygg.close(pygg.SET, pygg.STATUS_OLD, setout)
    pygg.close(pygg.WELL, pygg.STATUS_NEW, welname)
    print(f"Deleted log {logout} in set {setout} of well {welname}.\n")
    pygg.term();

def doc_geolog_pygg(file_name="doc_geolog_pygg.txt", long_version=True):
    with open(file_name, 'w') as f:
        for lib in ["geolog", "pygg"]:
            f.write(f"\nContents of {lib} library:\n")
            for element in dir(lib):
                f.write(f"\n\nLibrary element = {lib}.{element}\n")
                if long_version:
                    f.write(element.__doc__ + "\n\n\n")

def doc_logs(file_name="doc_logs.txt"):
    with open(file_name, "w") as fh:
        wlist = make_well_list()
        for w in wlist:
            fh.write(f"\n\n\n")
            fh.write("{:<25} {:<25} {:<28}".format("Well name", "Set name", "Log name\n"))
            slist = make_set_list(w)
            for s in slist:
                llist = make_log_list(w,s)
                for l in llist:
                    fh.write("{:<26} {:<26} {:<28}".format(w, s, l+"\n"))

def make_log_list(welname, setname):
    prjname = os.environ.get("PG_PROJECT")
    if not pygg.init(prjname):
        print(f"...Project {prjname} could not be initialized.\n")
        sys.exit()
    if not pygg.open("WELL", pygg.STATUS_OLD, welname):
        print(f"...Well {welname} could not be opened.\n")
        pygg.term()
        sys.exit()
    if not pygg.open("SET", pygg.STATUS_OLD, setname):
        print(f"   ...Set {setname} could not be opened.\n")
        pygg.close("WELL", pygg.STATUS_OLD, welname)
        pygg.term()
        sys.exit()
    result, logname = pygg.getc(pygg.NEXT_LOG, pygg.STATUS_OLD)
    log_list = list()
    while result:
        if not pygg.open(pygg.LOG, pygg.STATUS_OLD, logname):
            print(f"      Log {logname} could not be opened.\n")
            pygg.close(pygg.SET, pygg.STATUS_OLD, setname)
            pygg.close(pygg.WELL, pygg.STATUS_OLD, welname)
            pygg.term()
            sys.exit()
        log_list.append(logname)
        pygg.close(pygg.LOG, pygg.STATUS_OLD, logname)
        result, logname = pygg.getc(pygg.NEXT_LOG, pygg.STATUS_OLD)
    pygg.close(pygg.SET, pygg.STATUS_OLD, setname)
    pygg.close(pygg.WELL, pygg.STATUS_OLD, welname)
    pygg.term()
    return log_list

def make_set_list(welname):
    prjname = os.environ.get("PG_PROJECT")
    if not pygg.init(prjname):
        print(f"...Project {prjname} could not be initialized.\n")
        sys.exit()
    if not pygg.open("WELL", pygg.STATUS_OLD, welname):
        print(f"...Well {welname} could not be opened.\n")
        pygg.term()
        sys.exit()
    result, setname = pygg.getc(pygg.NEXT_SET, pygg.STATUS_OLD)
    set_list = list()
    while result:
        if not pygg.open("SET", pygg.STATUS_OLD, setname):
            print(f"   ...Set {setname} could not be opened.\n")
            pygg.close("WELL", pygg.STATUS_OLD, welname)
            pygg.term()
            sys.exit()
        set_list.append(setname)
        pygg.close(pygg.SET, pygg.STATUS_OLD, setname)
        result, setname = pygg.getc(pygg.NEXT_SET, pygg.STATUS_OLD)
    pygg.close(pygg.WELL, pygg.STATUS_OLD, welname)
    pygg.term()
    return set_list

def make_well_list():
    prjname = os.environ.get("PG_PROJECT")
    if not pygg.init(prjname):
        print(f"...Project {prjname} could not be initialized.\n")
        sys.exit()
    result, welname = pygg.getc(pygg.NEXT_WELL, pygg.STATUS_OLD)
    well_list = list()
    while result:
        well_list.append(welname)
        if not pygg.open("WELL", pygg.STATUS_OLD, welname):
            print(f"...Well {welname} could not be opened.\n")
            pygg.term()
            sys.exit()
        pygg.close(pygg.WELL, pygg.STATUS_OLD, welname)
        result, welname = pygg.getc(pygg.NEXT_WELL, pygg.STATUS_OLD)
    pygg.term()
    return well_list

def write_well_list(file_name="well_list.txt"):
    with open(file_name, 'w') as f:
        current_max_size = -1
        current_max_name = ""
        for w in make_well_list():
            f.write(w + '\n')
            if (len(w) > current_max_size):
                current_max_size = len(w)
                current_max_name = w
        f.write("\n\n")
        f.write("First well with max size " + str(current_max_size) + " is " + current_max_name)

def write_well_stat_by_country(file_name="stats.txt"):
    wl = make_well_list()
    cdict = dict()
    for w in wl:
        cid = w[0:2]                 
        if not cid in cdict:
            cdict[cid] = 1
        else:
            cdict[cid] += 1
    nw = 0
    with open(file_name, 'w') as f:
        for key, value in cdict.items():
            f.write(key + " : " + str(value) + "\n")
            nw += value
        f.write("\nTotal number of wells = " + str(nw))

def write_wells_without_set(setname, file_name="miss.txt"):
    well_list = make_well_list()
    miss_well_list = list()
    with open(file_name, 'w') as f:
        for well in well_list:
            st = make_set_list(well)
            if not setname in st:
                f.write(well + '\n')

def report_wells_sets_logs():
    prjname = os.environ.get("PG_PROJECT")
    if not pygg.init(prjname):
        print(f"...Project {prjname} could not be initialized.\n")
        sys.exit()
    result, welname = pygg.getc(pygg.NEXT_WELL, pygg.STATUS_OLD)
    well_list = list()
    while result:
        well_list.append(welname)
        if not pygg.open("WELL", pygg.STATUS_OLD, welname):
            print(f"...Well {welname} could not be opened.\n")
            pygg.term()
            sys.exit()
        result, setname = pygg.getc(pygg.NEXT_SET, pygg.STATUS_OLD)
        set_list = list()
        while result:
            if not pygg.open("SET", pygg.STATUS_OLD, setname):
                print(f"   ...Set {setname} could not be opened.\n")
                pygg.close("WELL", pygg.STATUS_OLD, welname)
                pygg.term()
                sys.exit()
            result, constant = pygg.getc(pygg.NEXT_CONSTANT, setname)
            set_list.append(setname)
            while result:
                result, string = pygg.getc(pygg.CONSTANT_VALUE, constant)
                if result:
                    result, type = pygg.getc(pygg.CONSTANT_TYPE, constant)
                    result, repeat = pygg.getc(pygg.CONSTANT_REPEAT, constant)
                result, constant = pygg.getc(pygg.NEXT_CONSTANT, setname)
            result, setcomm = pygg.getc(pygg.NEXT_COMMENT, setname)
            while result:
                result, string = pygg.getc(pygg.COMMENT_VALUE, setcomm)
                if result:
                    result, type = pygg.getc(pygg.COMMENT_TYPE, setcomm)
                    result, repeat = pygg.getc(pygg.COMMENT_REPEAT, setcomm)
                result, setcomm = pygg.getc(pygg.NEXT_COMMENT, setname)
            result, logname = pygg.getc(pygg.NEXT_LOG, pygg.STATUS_OLD)
            while result:
                if pygg.open(pygg.LOG, pygg.STATUS_OLD, logname):
                    result, attribute = pygg.getc(pygg.NEXT_ATTRIBUTE, logname)
                    while result:
                        if attribute[:5] == "AUDIT": continue;
                        attr_name = pygg.LOG + "_" + attribute
                        result, string = pygg.getc(attr_name, logname)
                        if not result: break;
                        result, attribute = pygg.getc(pygg.NEXT_ATTRIBUTE, logname)
                else:
                    print(f"      Log {logname} could not be opened.\n")
                    pygg.close(pygg.SET, pygg.STATUS_OLD, setname)
                    pygg.close(pygg.WELL, pygg.STATUS_OLD, welname)
                    pygg.term()
                    sys.exit()
                result, coments = pygg.getc ( pygg.LOG_COMMENT, logname)
                pygg.close(pygg.LOG, pygg.STATUS_OLD, logname)
                result, logname = pygg.getc(pygg.NEXT_LOG, pygg.STATUS_OLD)
            pygg.close(pygg.SET, pygg.STATUS_OLD, setname)
            result, setname = pygg.getc(pygg.NEXT_SET, pygg.STATUS_OLD)
        pygg.close(pygg.WELL, pygg.STATUS_OLD, welname)
        result, welname = pygg.getc(pygg.NEXT_WELL, pygg.STATUS_OLD)
    pygg.term()
    print("End of wells in this project.\n")
    return well_list


# Source: https://en.wikipedia.org/wiki/ISO_3166-1_alpha-2
# Note: Officially assigned code elements and Exceptional reservations

iso_3166_1_alpha_2 = {
    "AC": "Ascension Island",
    "AD": "Andorra",
    "AE": "United Arab Emirates",
    "AF": "Afghanistan",
    "AG": "Antigua and Barbuda",
    "AI": "Anguilla",
    "AL": "Albania",
    "AM": "Armenia",
    "AO": "Angola",
    "AQ": "Antarctica",
    "AR": "Argentina",
    "AS": "American Samoa",
    "AT": "Austria",
    "AU": "Australia",
    "AW": "Aruba",
    "AX": "Åland Islands",
    "AZ": "Azerbaijan",
    "BA": "Bosnia and Herzegovina",
    "BB": "Barbados",
    "BD": "Bangladesh",
    "BE": "Belgium",
    "BF": "Burkina Faso",
    "BG": "Bulgaria",
    "BH": "Bahrain",
    "BI": "Burundi",
    "BJ": "Benin",
    "BL": "Saint Barthélemy",
    "BM": "Bermuda",
    "BN": "Brunei Darussalam",
    "BO": "Bolivia (Plurinational State of)",
    "BQ": "Bonaire, Sint Eustatius and Saba",
    "BR": "Brazil",
    "BS": "Bahamas",
    "BT": "Bhutan",
    "BV": "Bouvet Island",
    "BW": "Botswana",
    "BY": "Belarus",
    "BZ": "Belize",
    "CA": "Canada",
    "CC": "Cocos (Keeling) Islands",
    "CD": "Congo, Democratic Republic of the",
    "CF": "Central African Republic",
    "CG": "Congo",
    "CH": "Switzerland",
    "CI": "Côte d'Ivoire",
    "CK": "Cook Islands",
    "CL": "Chile",
    "CM": "Cameroon",
    "CN": "China",
    "CO": "Colombia",
    "CP": "Clipperton Island",
    "CQ": "Island of Sark",
    "CR": "Costa Rica",
    "CU": "Cuba",
    "CV": "Cabo Verde",
    "CW": "Curaçao",
    "CX": "Christmas Island",
    "CY": "Cyprus",
    "CZ": "Czechia",
    "DE": "Germany",
    "DG": "Diego Garcia",
    "DJ": "Djibouti",
    "DK": "Denmark",
    "DM": "Dominica",
    "DO": "Dominican Republic",
    "DZ": "Algeria",
    "EA": "Ceuta, Melilla",
    "EC": "Ecuador",
    "EE": "Estonia",
    "EG": "Egypt",
    "EH": "Western Sahara",
    "ER": "Eritrea",
    "ES": "Spain",
    "ET": "Ethiopia",
    "EU": "European Union",
    "EZ": "Eurozone",
    "FI": "Finland",
    "FJ": "Fiji",
    "FK": "Falkland Islands (Malvinas)",
    "FM": "Micronesia (Federated States of)",
    "FO": "Faroe Islands",
    "FR": "France",
    "FX": "France, Metropolitan",
    "GA": "Gabon",
    "GB": "United Kingdom of Great Britain and Northern Ireland",
    "GD": "Grenada",
    "GE": "Georgia",
    "GF": "French Guiana",
    "GG": "Guernsey",
    "GH": "Ghana",
    "GI": "Gibraltar",
    "GL": "Greenland",
    "GM": "Gambia",
    "GN": "Guinea",
    "GP": "Guadeloupe",
    "GQ": "Equatorial Guinea",
    "GR": "Greece",
    "GS": "South Georgia and the South Sandwich Islands",
    "GT": "Guatemala",
    "GU": "Guam",
    "GW": "Guinea-Bissau",
    "GY": "Guyana",
    "HK": "Hong Kong",
    "HM": "Heard Island and McDonald Islands",
    "HN": "Honduras",
    "HR": "Croatia",
    "HT": "Haiti",
    "HU": "Hungary",
    "IC": "Canary Islands",
    "ID": "Indonesia",
    "IE": "Ireland",
    "IL": "Israel",
    "IM": "Isle of Man",
    "IN": "India",
    "IO": "British Indian Ocean Territory",
    "IQ": "Iraq",
    "IR": "Iran (Islamic Republic of)",
    "IS": "Iceland",
    "IT": "Italy",
    "JE": "Jersey",
    "JM": "Jamaica",
    "JO": "Jordan",
    "JP": "Japan",
    "KE": "Kenya",
    "KG": "Kyrgyzstan",
    "KH": "Cambodia",
    "KI": "Kiribati",
    "KM": "Comoros",
    "KN": "Saint Kitts and Nevis",
    "KP": "Korea (Democratic People's Republic of)",
    "KR": "Korea, Republic of",
    "KW": "Kuwait",
    "KY": "Cayman Islands",
    "KZ": "Kazakhstan",
    "LA": "Lao People's Democratic Republic",
    "LB": "Lebanon",
    "LC": "Saint Lucia",
    "LI": "Liechtenstein",
    "LK": "Sri Lanka",
    "LR": "Liberia",
    "LS": "Lesotho",
    "LT": "Lithuania",
    "LU": "Luxembourg",
    "LV": "Latvia",
    "LY": "Libya",
    "MA": "Morocco",
    "MC": "Monaco",
    "MD": "Moldova, Republic of",
    "ME": "Montenegro",
    "MF": "Saint Martin (French part)",
    "MG": "Madagascar",
    "MH": "Marshall Islands",
    "MK": "North Macedonia",
    "ML": "Mali",
    "MM": "Myanmar",
    "MO": "Macao",
    "MP": "Northern Mariana Islands",
    "MQ": "Martinique",
    "MR": "Mauritania",
    "MS": "Montserrat",
    "MT": "Malta",
    "MU": "Mauritius",
    "MV": "Maldives",
    "MW": "Malawi",
    "MX": "Mexico",
    "MY": "Malaysia",
    "MZ": "Mozambique",
    "NA": "Namibia",
    "NC": "New Caledonia",
    "NE": "Niger",
    "NF": "Norfolk Island",
    "NG": "Nigeria",
    "NI": "Nicaragua",
    "NL": "Netherlands",
    "NO": "Norway",
    "NP": "Nepal",
    "NR": "Nauru",
    "NU": "Niue",
    "NZ": "New Zealand",
    "OM": "Oman",
    "PA": "Panama",
    "PE": "Peru",
    "PF": "French Polynesia",
    "PG": "Papua New Guinea",
    "PH": "Philippines",
    "PK": "Pakistan",
    "PL": "Poland",
    "PM": "Saint Pierre and Miquelon",
    "PN": "Pitcairn",
    "PR": "Puerto Rico",
    "PS": "Palestine, State of",
    "PT": "Portugal",
    "PW": "Palau",
    "PY": "Paraguay",
    "QA": "Qatar",
    "RE": "Réunion",
    "RO": "Romania",
    "RS": "Serbia",
    "RU": "Russian Federation",
    "RW": "Rwanda",
    "SA": "Saudi Arabia",
    "SB": "Solomon Islands",
    "SC": "Seychelles",
    "SD": "Sudan",
    "SE": "Sweden",
    "SG": "Singapore",
    "SH": "Saint Helena, Ascension and Tristan da Cunha",
    "SI": "Slovenia",
    "SJ": "Svalbard and Jan Mayen",
    "SK": "Slovakia",
    "SL": "Sierra Leone",
    "SM": "San Marino",
    "SN": "Senegal",
    "SO": "Somalia",
    "SR": "Suriname",
    "SS": "South Sudan",
    "ST": "Sao Tome and Principe",
    "SU": "USSR",
    "SV": "El Salvador",
    "SX": "Sint Maarten (Dutch part)",
    "SY": "Syrian Arab Republic",
    "SZ": "Eswatini",
    "TA": "Tristan da Cunha",
    "TC": "Turks and Caicos Islands",
    "TD": "Chad",
    "TF": "French Southern Territories",
    "TG": "Togo",
    "TH": "Thailand",
    "TJ": "Tajikistan",
    "TK": "Tokelau",
    "TL": "Timor-Leste",
    "TM": "Turkmenistan",
    "TN": "Tunisia",
    "TO": "Tonga",
    "TR": "Turkey",
    "TT": "Trinidad and Tobago",
    "TV": "Tuvalu",
    "TW": "Taiwan, Province of China",
    "TZ": "Tanzania, United Republic of",
    "UA": "Ukraine",
    "UG": "Uganda",
    "UK": "United Kingdom",
    "UM": "United States Minor Outlying Islands",
    "UN": "United Nations",
    "US": "United States of America",
    "UY": "Uruguay",
    "UZ": "Uzbekistan",
    "VA": "Holy See",
    "VC": "Saint Vincent and the Grenadines",
    "VE": "Venezuela (Bolivarian Republic of)",
    "VG": "Virgin Islands (British)",
    "VI": "Virgin Islands (U.S.)",
    "VN": "Viet Nam",
    "VU": "Vanuatu",
    "WF": "Wallis and Futuna",
    "WS": "Samoa",
    "YE": "Yemen",
    "YT": "Mayotte",
    "ZA": "South Africa",
    "ZM": "Zambia",
    "ZW": "Zimbabwe"
}

set_iso_3166_1_alpha_2 = {el for el in iso_3166_1_alpha_2.keys()}

#  G:\Sub_Appl_Data\SDTC\DataFlows\Well_Header\​Ref0007_Standard - Well naming in Equinor.xlsx​

