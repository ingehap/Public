'''
List of functions:
- vp_over_vs - vp/vs
- vp_over_vs - vs/vp
'''

def vp_over_vs(vp, vs):
    vp_vs_ratio = vp / vs
    return vp_vs_ratio

def vs_over_vp(vs, vp):
    vs_vp_ratio = vs / vp 
    return vs_vp_ratio

