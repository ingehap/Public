import configparser
import csv
import glob
import missingno as msno         # https://github.com/ResidentMario/missingno
import numpy as np
import os
import pandas as pd
import pylab
import statsmodels.api as sm
import sys
from xlsxwriter.workbook import Workbook

config = configparser.ConfigParser()
config.read('./equinor.ini')
    
MY_SYS_PATH = sys.path

def csv2xlsx(path='.'):
    for csvfile in glob.glob(os.path.join(path, '*.csv')):
        workbook = Workbook(csvfile[:-4] + '.xlsx')
        worksheet = workbook.add_worksheet()
        with open(csvfile, 'rt', encoding='unicode_escape') as f:
            reader = csv.reader(f)
            for r, row in enumerate(reader):
                for c, col in enumerate(row):
                    worksheet.write(r, c, col)
        workbook.close()
    
def qq_plot(x_list):
    x = np.array(x_list, dtype=np.float64)
    ave = np.mean(x)
    s_sdev = np.std(x, ddof=1)
    print('Average is ', ave)
    print('Sample standard deviation is ', s_sdev)
    norm_residual = (x - ave) / s_sdev
    sm.qqplot(norm_residual, line='45')
    pylab.show()
    
def show_nullity_vals(csv_file):
    data = pd.read_csv(csv_file)
    msno.matrix(data) # white lines are missing values

def show_nullity_dendrogram(csv_file):
    data = pd.read_csv(csv_file)
    msno.dendrogram(data)

def show_nullity_correlation(csv_file):
    data = pd.read_csv(csv_file)
    msno.heatmap(data)

def show_nullity_by_col(csv_file):
    data = pd.read_csv(csv_file)
    msno.bar(data)

def main():
    pass

if __name__ == '__main__':
    main()



