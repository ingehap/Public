def get_mineral_table():
    mineral = np.array(['muscovite', 'biotite', 'glauconite', 'kaolinite', 'illite1', 'illite2', 'smectite', 'chlorite'], dtype = str)
    a = np.array([5.21, 5.33, 5.24, 5.16, 5.21, 5.20, 5.17, 5.39], dtype = np.float64)
    b = np.array([9.03, 9.22, 9.08, 8.94, 9.02, 9.01, 8.96, 9.34], dtype = np.float64)
    c = np.array([10.00, 10.00, 10.00, 7.38, 10.00, 10.00, 9.60, 14.26], dtype = np.float64)
    atomic_mass = np.array([796.6, 893.0, 848.6, 516.7, 791.7, 784.0, 747.9, 1168.7], dtype = np.float64)
    density = (10.0 / 6.023) * atomic_mass / (a * b * c)
    iw = np.array([0.0, 0.0, 0.0, 0.0, 3.5, 0.9, 28.6, 0.0], dtype = np.float64)
    features = (mineral, a, b, c, atomic_mass, density, iw)    
    cols = ['mineral', 'a (Å)', 'b (Å)', 'c (Å)', 'atomic mass (g/mol)', 'density (g/cm3)', 'IW (%)']                                                                 
    matrix = pd.DataFrame(np.stack(features, axis=1), columns=cols)
    return matrix
    
def hi_from_aps(aps_sst_por):
    # R**2 = 0.96
    # APS = accelerated porosity sonde
    return (0.896 * aps_sst_por + 0.0136)

def hi_from_cnl(cnl_sst_por):
    # R**2 = 0.84
    # CNL = compensated neutron log
    return (0.7662 * aps_sst_por + 0.0058)
