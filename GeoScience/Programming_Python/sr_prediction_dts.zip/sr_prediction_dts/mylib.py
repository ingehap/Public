#!/usr/bin/env python3

from itertools import combinations

def ncr(n, r):
    arr = [x for x in range(n)]
    return list(combinations(arr,r))

# driver
if __name__ == "__main__":
    print(ncr(4,2))
